import React from 'react';

export default function Chatbot() {
  return null;
}