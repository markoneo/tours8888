export const cities = [
  // Sample data - in production, this would be a more comprehensive database
  { city: 'New York', state: 'NY', zip: '10001' },
  { city: 'Los Angeles', state: 'CA', zip: '90001' },
  { city: 'Chicago', state: 'IL', zip: '60601' },
  { city: 'Houston', state: 'TX', zip: '77001' },
  { city: 'Miami', state: 'FL', zip: '33101' },
  { city: 'San Francisco', state: 'CA', zip: '94101' },
  { city: 'Boston', state: 'MA', zip: '02101' },
  { city: 'Seattle', state: 'WA', zip: '98101' },
  { city: 'Denver', state: 'CO', zip: '80201' },
  { city: 'Atlanta', state: 'GA', zip: '30301' }
];