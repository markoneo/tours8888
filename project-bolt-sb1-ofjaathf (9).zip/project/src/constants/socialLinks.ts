import { Facebook, Instagram } from 'lucide-react';

export const socialLinks = [
  {
    name: 'Facebook',
    icon: Facebook,
    url: 'https://www.facebook.com/rideconnect.2024',
  },
  {
    name: 'Instagram',
    icon: Instagram,
    url: 'https://www.instagram.com/rideconnect__/',
  },
];