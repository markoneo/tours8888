export const heroImages = {
  main: "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&q=80&w=1920",
  // Add more images here if needed
};